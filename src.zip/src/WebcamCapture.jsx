import React, { useRef, useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Camera, Download, X } from "lucide-react";
import { saveAs } from "file-saver";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

const filters = [
  { name: "none", label: "None" },
  { name: "vintage", label: "Vintage" },
  { name: "retro", label: "Retro" },
  { name: "classic", label: "Classic" },
  { name: "warm", label: "Warm" },
  { name: "cool", label: "Cool" },
  { name: "bw", label: "B&W" },
];

const WebcamCapture = ({ open, setOpen }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [selectedFilter, setSelectedFilter] = useState("none");

  useEffect(() => {
    if (open) {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
          }
        })
        .catch((err) => console.error("Error accessing webcam:", err));
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
      setCapturedImage(null);
      setSelectedFilter("none");
    }
  }, [open]);

  const applyFilterToCanvas = (ctx, filter) => {
    const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
    const data = imageData.data;

    switch (filter) {
      case "vintage":
        for (let i = 0; i < data.length; i += 4) {
          data[i] = data[i] * 1.1 + 30;
          data[i + 1] = data[i + 1] * 0.95 + 10;
          data[i + 2] = data[i + 2] * 0.8;
        }
        break;

      case "retro":
        for (let i = 0; i < data.length; i += 4) {
          const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
          data[i] = avg + 30;
          data[i + 1] = avg + 15;
          data[i + 2] = avg - 20;
        }
        break;

      case "classic":
        for (let i = 0; i < data.length; i += 4) {
          data[i] *= 1.2;
          data[i + 1] *= 1.2;
          data[i + 2] *= 1.2;
        }
        break;

      case "warm":
        for (let i = 0; i < data.length; i += 4) {
          data[i] += 20;
          data[i + 1] += 10;
          data[i + 2] -= 10;
        }
        break;

      case "cool":
        for (let i = 0; i < data.length; i += 4) {
          data[i] -= 10;
          data[i + 1] += 10;
          data[i + 2] += 20;
        }
        break;

      case "bw":
        for (let i = 0; i < data.length; i += 4) {
          const gray = 0.3 * data[i] + 0.59 * data[i + 1] + 0.11 * data[i + 2];
          data[i] = data[i + 1] = data[i + 2] = gray;
        }
        break;

      default:
        break;
    }

    ctx.putImageData(imageData, 0, 0);
  };

  const capturePhoto = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;

    if (!canvas || !video) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    applyFilterToCanvas(ctx, selectedFilter);

    const image = canvas.toDataURL("image/png");
    setCapturedImage(image);
  };

  const downloadImage = () => {
    if (capturedImage) {
      saveAs(capturedImage, "photo.png");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-4xl p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl font-bold flex items-center justify-between">
            Capture a Polaroid
            <Button size="icon" variant="ghost" onClick={() => setOpen(false)}>
              <X />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <video
            ref={videoRef}
            className="rounded-xl w-full max-w-md border"
            autoPlay
            muted
          />
          <canvas ref={canvasRef} className="hidden" />
          {capturedImage && (
            <img
              src={capturedImage}
              alt="Captured"
              className="rounded-xl border w-full max-w-xs"
            />
          )}
        </div>

        <div className="flex justify-center mt-6">
          <ToggleGroup
            type="single"
            value={selectedFilter}
            onValueChange={(val) => setSelectedFilter(val || "none")}
            className="flex flex-wrap gap-2"
          >
            {filters.map((filter) => (
              <ToggleGroupItem key={filter.name} value={filter.name}>
                {filter.label}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
        </div>

        <DialogFooter className="mt-6 flex justify-center gap-4">
          <Button onClick={capturePhoto} className="gap-2">
            <Camera className="w-5 h-5" /> Capture
          </Button>
          {capturedImage && (
            <Button onClick={downloadImage} className="gap-2" variant="outline">
              <Download className="w-5 h-5" /> Download
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default WebcamCapture;
