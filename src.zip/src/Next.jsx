import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import * as htmlToImage from 'html-to-image';

const photostripColors = ['#ffffff', '#f8f1e4', '#d2ab80', '#b3b792', '#809671'];
const backgroundColors = ['#E5E0D8', '#F9F7F3', '#725C3A', '#D2AB80', '#B3B792'];

const Next = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const images = location.state?.images || [];
  const selectedFilter = location.state?.selectedFilter || '';

  // Add some test images if none are provided for debugging
  const testImages = [
    'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjY2NjIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzMzMyIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIDE8L3RleHQ+PC9zdmc+',
    'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjYmJiIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzMzMyIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIDI8L3RleHQ+PC9zdmc+',
    'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjYWFhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzMzMyIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIDM8L3RleHQ+PC9zdmc+'
  ];
  
  // Use test images if no real images are provided
  const displayImages = images.length > 0 ? images : testImages;

  const [step, setStep] = useState(1);
  const [sharedNote, setSharedNote] = useState('');
  const [photostripColor, setPhotostripColor] = useState(photostripColors[0]);
  const [backgroundColor, setBackgroundColor] = useState(backgroundColors[0]);
  const [showDate, setShowDate] = useState(true);

  const polaroidRef = useRef();

  useEffect(() => {
    console.log('=== DEBUG INFO ===');
    console.log('Images received:', images);
    console.log('Images length:', images.length);
    console.log('Location state:', location.state);
    console.log('Display images:', displayImages);
    console.log('==================');
    
    // Don't redirect if we have test images to show
    if (images.length === 0 && displayImages.length === 0) {
      console.warn('No images found, redirecting to home');
      navigate('/', { replace: true });
    }
  }, [images, navigate, location.state, displayImages]);

  const handleDownload = async () => {
    try {
      const dataUrl = await htmlToImage.toPng(polaroidRef.current, {
        width: polaroidRef.current.offsetWidth * 2,
        height: polaroidRef.current.offsetHeight * 2,
        pixelRatio: 2,
        quality: 1,
        cacheBust: true
      });
      
      const link = document.createElement('a');
      link.download = 'vintage-photostrip.png';
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error generating image:', error);
    }
  };

  const getDateString = () => {
    const d = new Date();
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getFilterStyle = () => {
    switch (selectedFilter) {
      case 'sepia':
        return 'sepia(60%) contrast(110%) brightness(90%)';
      case 'blackAndWhite':
        return 'grayscale(100%) contrast(120%)';
      case 'vintage':
        return 'sepia(40%) contrast(120%) brightness(90%) hue-rotate(-10deg)';
      case 'warm':
        return 'sepia(30%) contrast(110%) brightness(105%) hue-rotate(5deg)';
      default:
        return 'sepia(10%) contrast(110%) brightness(95%)';
    }
  };

  if (displayImages.length === 0) {
    return (
      <div style={{ 
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center', 
        justifyContent: 'center', 
        height: '100vh',
        fontFamily: 'Quicksand, sans-serif',
        color: '#725C3A'
      }}>
        <h2>No images found</h2>
        <p>Please go back and capture or select some photos first.</p>
        <button onClick={() => navigate('/')}>Go to Home</button>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Quicksand:wght@500;700&family=Pacifico&family=Caveat:wght@400;600&display=swap');
        * {
          box-sizing: border-box;
        }
        body, html, #root {
          margin: 0; padding: 0;
          font-family: 'Quicksand', sans-serif;
          background-color: ${backgroundColor};
          color: #725C3A;
          height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          flex-direction: column;
        }
        button {
          cursor: pointer;
          padding: 10px 20px;
          border: none;
          border-radius: 8px;
          background-color: #809671;
          color: white;
          font-weight: 700;
          margin-top: 15px;
          transition: background-color 0.3s ease;
        }
        button:hover {
          background-color: #6a7c56;
        }
        textarea {
          font-family: 'Quicksand', sans-serif;
          width: 100%;
          height: 180px;
          padding: 20px;
          font-size: 18px;
          border-radius: 16px;
          border: 2px solid #725C3A;
          resize: none;
          box-shadow: inset 1px 1px 4px #d9d9d9;
          outline: none;
        }
        label {
          font-weight: 700;
          display: block;
          margin-bottom: 10px;
          font-size: 20px;
        }
        .container {
          background: white;
          padding: 40px;
          border-radius: 20px;
          box-shadow: 0 10px 25px rgba(0,0,0,0.1);
          max-width: 600px;
          width: 100%;
          text-align: left;
        }
        .next-button-wrapper {
          width: 600px;
          max-width: 100%;
          margin-top: 10px;
          display: flex;
          justify-content: flex-end;
        }
        .back-button {
          position: fixed;
          top: 20px;
          left: 20px;
          background-color: #725C3A;
          border: none;
          border-radius: 50%;
          width: 36px;
          height: 36px;
          cursor: pointer;
          color: #E5E0D8;
          font-size: 22px;
          font-weight: bold;
          line-height: 36px;
          text-align: center;
          user-select: none;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 1000;
        }
        .back-button:hover {
          background-color: #5a4a2f;
        }
        .step2-container, .step3-container {
          max-width: 700px;
          width: 100%;
          margin: 40px auto;
          text-align: center;
          background: white;
          padding: 30px 40px;
          border-radius: 20px;
          box-shadow: 0 10px 25px rgba(0,0,0,0.1);
          color: #725C3A;
        }
        .color-picker {
          display: flex;
          gap: 10px;
          justify-content: center;
          margin: 20px 0;
        }
        .color-box {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          cursor: pointer;
          border: 2px solid transparent;
          transition: border-color 0.3s ease;
        }
        .color-box.selected {
          border-color: #725C3A;
        }
        .checkbox-wrapper {
          margin-top: 15px;
          font-weight: 600;
          font-size: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          color: #725C3A;
          cursor: pointer;
          user-select: none;
        }
        .photostrip-wrapper {
          display: flex;
          justify-content: center;
          margin: 20px 0;
          perspective: 1000px;
        }
        .vintage-photostrip {
          width: 400px;
          background: linear-gradient(145deg, #f5f5f5, #e8e8e8);
          border-radius: 20px;
          padding: 20px 25px;
          box-shadow: 
            0 15px 35px rgba(0,0,0,0.2),
            inset 0 2px 10px rgba(255,255,255,0.8),
            inset 0 -2px 10px rgba(0,0,0,0.1);
          position: relative;
          transform: rotateY(-5deg) rotateX(2deg);
          transition: transform 0.3s ease;
          border: 2px solid #ddd;
          background: ${photostripColor};
        }
        .vintage-photostrip:hover {
          transform: rotateY(0deg) rotateX(0deg);
        }
        .vintage-photostrip::before {
          content: '';
          position: absolute;
          top: 15px;
          left: 15px;
          right: 15px;
          bottom: 15px;
          border: 1px dashed rgba(114, 92, 58, 0.3);
          border-radius: 15px;
          pointer-events: none;
        }
        .strip-header {
          text-align: center;
          margin-bottom: 15px;
          position: relative;
        }
        .strip-title {
          font-family: 'Caveat', cursive;
          font-size: 20px;
          font-weight: 600;
          color: #725C3A;
          margin: 0;
          text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
          position: relative;
        }
        .strip-title::after {
          content: '✦';
          position: absolute;
          left: -30px;
          top: 50%;
          transform: translateY(-50%);
          color: #809671;
          font-size: 16px;
        }
        .strip-title::before {
          content: '✦';
          position: absolute;
          right: -30px;
          top: 50%;
          transform: translateY(-50%);
          color: #809671;
          font-size: 16px;
        }
        .vintage-photos-container {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-bottom: 15px;
        }
        .vintage-photo-frame {
          background: white;
          padding: 8px;
          border-radius: 8px;
          box-shadow: 
            0 4px 8px rgba(0,0,0,0.15),
            inset 0 1px 3px rgba(255,255,255,0.8);
          position: relative;
          overflow: hidden;
        }
        .vintage-photo-frame::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
          pointer-events: none;
          z-index: 2;
        }
        .vintage-photo-frame img {
          width: 100%;
          height: 140px;
          object-fit: cover;
          border-radius: 4px;
          display: block;
          filter: ${getFilterStyle()};
        }
        .strip-footer {
          text-align: center;
          padding-top: 10px;
          border-top: 1px solid rgba(114, 92, 58, 0.2);
        }
        .strip-date {
          font-family: 'Caveat', cursive;
          font-size: 16px;
          font-weight: 600;
          color: #725C3A;
          margin: 5px 0;
        }
        .strip-note {
          font-family: 'Caveat', cursive;
          font-size: 14px;
          color: #809671;
          font-style: italic;
          margin: 5px 0;
          max-width: 320px;
          word-wrap: break-word;
          line-height: 1.3;
        }
        .vintage-corners {
          position: absolute;
          width: 20px;
          height: 20px;
          border: 2px solid rgba(114, 92, 58, 0.3);
        }
        .corner-tl {
          top: 10px;
          left: 10px;
          border-right: none;
          border-bottom: none;
        }
        .corner-tr {
          top: 10px;
          right: 10px;
          border-left: none;
          border-bottom: none;
        }
        .corner-bl {
          bottom: 10px;
          left: 10px;
          border-right: none;
          border-top: none;
        }
        .corner-br {
          bottom: 10px;
          right: 10px;
          border-left: none;
          border-top: none;
        }
        .film-holes {
          position: absolute;
          right: 5px;
          top: 20%;
          bottom: 20%;
          width: 8px;
          background: repeating-linear-gradient(
            to bottom,
            transparent 0px,
            transparent 15px,
            rgba(0,0,0,0.1) 15px,
            rgba(0,0,0,0.1) 25px
          );
          border-radius: 4px;
        }
        .download-btn {
          background: linear-gradient(145deg, #809671, #6a7c56);
          color: white;
          border: none;
          padding: 12px 30px;
          border-radius: 25px;
          font-family: 'Quicksand', sans-serif;
          font-weight: 700;
          font-size: 16px;
          cursor: pointer;
          box-shadow: 0 4px 15px rgba(128, 150, 113, 0.3);
          transition: all 0.3s ease;
          margin-top: 20px;
        }
        .download-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(128, 150, 113, 0.4);
        }
      `}</style>

      <button
        onClick={() => {
          if (step > 1) setStep(step - 1);
          else navigate('/');
        }}
        aria-label={step > 1 ? "Go to previous step" : "Go back to Home"}
        className="back-button"
      >
        ←
      </button>

      {step === 1 && (
        <>
          <div className="container">
            <label htmlFor="shared-note">Add a note!</label>
            <textarea
              id="shared-note"
              placeholder="Write your note here..."
              value={sharedNote}
              onChange={(e) => setSharedNote(e.target.value)}
            />
          </div>
          <div className="next-button-wrapper">
            <button onClick={() => setStep(2)}>Next</button>
          </div>
        </>
      )}

      {step === 2 && (
        <div className="step2-container">
          <h2>Choose Colors & Options</h2>

          <div>
            <h3>Photostrip Color</h3>
            <div className="color-picker">
              {photostripColors.map((color) => (
                <div
                  key={color}
                  className={`color-box ${photostripColor === color ? 'selected' : ''}`}
                  style={{ backgroundColor: color }}
                  onClick={() => setPhotostripColor(color)}
                  title={color}
                />
              ))}
            </div>
          </div>

          <div>
            <h3>Background Color</h3>
            <div className="color-picker">
              {backgroundColors.map((color) => (
                <div
                  key={color}
                  className={`color-box ${backgroundColor === color ? 'selected' : ''}`}
                  style={{ backgroundColor: color }}
                  onClick={() => setBackgroundColor(color)}
                  title={color}
                />
              ))}
            </div>
          </div>

          <label className="checkbox-wrapper">
            <input
              type="checkbox"
              checked={showDate}
              onChange={() => setShowDate(!showDate)}
            />
            Show Date on Photostrip
          </label>

          <div className="next-button-wrapper">
            <button onClick={() => setStep(3)}>Next</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="step3-container">
          <h2>Your Vintage Photostrip</h2>
          
          <div className="photostrip-wrapper">
            <div className="vintage-photostrip" ref={polaroidRef}>
              {/* Decorative corners */}
              <div className="vintage-corners corner-tl"></div>
              <div className="vintage-corners corner-tr"></div>
              <div className="vintage-corners corner-bl"></div>
              <div className="vintage-corners corner-br"></div>
              
              {/* Film holes */}
              <div className="film-holes"></div>
              
              {/* Header */}
              <div className="strip-header">
                <h3 className="strip-title">Photo is printing</h3>
              </div>
              
              {/* Photos */}
              <div className="vintage-photos-container">
                {displayImages.map((imgSrc, index) => (
                  <div className="vintage-photo-frame" key={index}>
                    <img src={imgSrc} alt={`Vintage photo ${index + 1}`} />
                  </div>
                ))}
              </div>
              
              {/* Footer */}
              <div className="strip-footer">
                {showDate && <div className="strip-date">{getDateString()}</div>}
                {sharedNote.trim() && (
                  <div className="strip-note">"{sharedNote}"</div>
                )}
              </div>
            </div>
          </div>
          
          <button className="download-btn" onClick={handleDownload}>
            Download Photostrip
          </button>
        </div>
      )}
    </>
  );
};

export default Next;